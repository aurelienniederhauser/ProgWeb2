<script src="cards.js" type="module"></script>

console.log('cards.js est chargé');

const deckElement = document.querySelector('.deck');
console.log(deckElement);